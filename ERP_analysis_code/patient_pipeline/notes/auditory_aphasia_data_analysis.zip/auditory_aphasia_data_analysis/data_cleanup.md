# Data cleanup for all patients
This file contains all data files that need a correction. This is provided for every patient.

First of all, I anonymized the data using [Simon's script](https://github.com/simonkojima/anonymize-bv) and then renamed every session folder. For instance, for patient 1, session 1 was renamed to P1_S1, session 2 renamed to P1_S2, etc. As a result of Simon's script, the contents of the original session folder is now moved to P1_S1/anonymized/.

All changes I am intending to take after analyzing all files and markers are one of the following:
- **"removed"**: I move the filename into a new folder called `2025_bin` (in the same directory), so it cannot be loaded anymore.
- **"renamed"**: I list here the old filenames and then the new filenames, after renaming them. Important here is that you also have to change the contents of the corresponding .vmrk and .vhdr files, since they contain a reference to the corresponding DataFile and MarkerFile.

I collected this information by checking the results of the markers scripts, by loading all the data and tracking iterations that are missing a certain word (yielding an error) and by manually checking all filenames of a patient. The list of all filenames is found in `markers/unique_markers/p*_marker_information`. Note that it contains a complete list of all original files, without any changes from my side.

## Patient 1 

## Patient 2

#### Data cleanup
- Session 13: I **removed** `auditoryAphasia_6D_350_Block3_Run5.vmrk` and the corresponding .eeg and.vhdr files.
    - This run contains only 2 markers and the corresponding .eeg file is very small.

## Patient 3:

#### Data cleanup
- Session 14: I **removed** run: `auditoryAphasia_HP_250_Block2_Run4.vmrk` and the corresponding .eeg and.vhdr files.
    - This run seemed to be missing either a S103 or S113 marker. I encountered an error when preprocessing the data of patient 3 that there was an iteration (after combining all epochs in groups of 6) without a target word. When I counted the amount of words per word id (1,2,3,4,5,6, summing both target and nontarget occurences for each), every word appeared 60 times, except from word 3, which appeared 59 times.

## Patient 4

#### Data cleanup
- Session 9: I **removed** run `auditoryAphasia_6D_350_Block3_Run6.vmrk` and the corresponding .eeg and .vhdr files.
    - This run contains only the following unique markers: [101 102 103 104 105 106 111 113 200 202 210 211], which is strange. There are 104 markers in total, and it seems that only trial 1 + the first iteration of trial 2 was recorded. The corresponding .eeg file is ~6500 KB, while all other .eeg files are ~21000 KB. 

- Session 13: Block 1, run 1-3 appeared at the end of the file after Block 3, because of the condition in the filename (400 comes after 350 when you order it). So we get:

    ```
    ...
    P4_S13/anonymized/auditoryAphasia_HP_350_Block3_Run5.vhdr
    P4_S13/anonymized/auditoryAphasia_HP_400_Block1_Run3.vhdr
    P4_S13/anonymized/auditoryAphasia_HP_450_Block1_Run1.vhdr
    P4_S13/anonymized/auditoryAphasia_HP_450_Block1_Run2.vhdr
    ```

    This is not chronologically ordered. Therefore, I **renamed** the files of Block 1, run 1-3 to the following:

    ```
    ...
    P4_S13/anonymized/auditoryAphasia_HP_350_Block3_Run5.vhdr
    P4_S13/anonymized/auditoryAphasia_03HP_400_Block1_Run3.vhdr
    P4_S13/anonymized/auditoryAphasia_01HP_450_Block1_Run1.vhdr
    P4_S13/anonymized/auditoryAphasia_02HP_450_Block1_Run2.vhdr
    ```

    I also **renamed** the corresponding .vmrk and .eeg files. Keep in mind that the content of the .vmrk and .vhdr files with `DataFile = ...` and `MarkerFile = ...` have to be changed too! Now, after refreshing, they all appear in chronologial order.

## Patient 5

## Patient 6

## Patient 7
- Session 22: I **removed** run: `auditoryAphasia_6D_350_Block1_Run5.vmrk` and the corresponding .eeg and.vhdr files.
    - I encountered an error during preprocessing: there was an iteration (after combining all epochs in groups of 6) without word 1. It seems that this error was caused by a missing S101 marker all the way at the end, during the final iteration of the final trial.

## Patient 8
- Session 17: I **removed** run: `auditoryAphasia_HP_250_Block1_Run2.vmrk` and the corresponding .eeg and.vhdr files.
    - This run seemed to be missing a S106 marker in the final iteration of the trial where S114 was the target. Counting the occurences of each word gave 54 per word, except from word 6, which occurred 53 times in total. 
    The error I encountered was a bit strange though... When loading the data of session 17, an error showed up that there was an iteration (after combining all epochs in groups of 6) without word 1 (as a non target). This was also the case when loading the data of only session 17, block 1. But, when loading the data of session 17, block 1, run 2 (the other runs did not give an error), the error message was that word 2 (as a target) was missing...

## Patient 9

#### Data cleanup
- Session 15: Block 1, runs 1-6 appeared at the end of the file, because of the condition in the filename (HP 1000 comes before HP 650 when you order it). So we get:

    ```
    ...
    P9_S15/anonymized/auditoryAphasia_HP_1000_Block2_Run6.vhdr
    P9_S15/anonymized/auditoryAphasia_HP_1000_Block3_Run1.vhdr
    P9_S15/anonymized/auditoryAphasia_HP_650_Block1_Run1.vhdr
    P9_S15/anonymized/auditoryAphasia_HP_650_Block1_Run2.vhdr
    P9_S15/anonymized/auditoryAphasia_HP_650_Block1_Run3.vhdr
    P9_S15/anonymized/auditoryAphasia_HP_650_Block1_Run4.vhdr
    P9_S15/anonymized/auditoryAphasia_HP_650_Block1_Run5.vhdr
    P9_S15/anonymized/auditoryAphasia_HP_650_Block1_Run6.vhdr
    ```

    This is not chronologically ordered. When I open the folder, it seems to be chronologically ordered, but when I load the filenames in the code, it is ordered as seen here above. Therefore, I **renamed** the files of Block 1: runs 1-6 to the following:

    ```
    ...
    P9_S15/anonymized/auditoryAphasia_HP_1000_Block2_Run6.vhdr
    P9_S15/anonymized/auditoryAphasia_HP_1000_Block3_Run1.vhdr
    P9_S15/anonymized/auditoryAphasia_01HP_650_Block1_Run1.vhdr
    P9_S15/anonymized/auditoryAphasia_02HP_650_Block1_Run2.vhdr
    P9_S15/anonymized/auditoryAphasia_03HP_650_Block1_Run3.vhdr
    P9_S15/anonymized/auditoryAphasia_04HP_650_Block1_Run4.vhdr
    P9_S15/anonymized/auditoryAphasia_05HP_650_Block1_Run5.vhdr
    P9_S15/anonymized/auditoryAphasia_06HP_650_Block1_Run6.vhdr
    ```

    I also **renamed** the corresponding .vmrk and .eeg files. Keep in mind that the content of the .vmrk and .vhdr files with `DataFile = ...` and `MarkerFile = ...` have to be changed too! Now, after refreshing, they are all loaded in chronologial order. 

## Patient 10

